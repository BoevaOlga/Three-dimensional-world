
const themeToggle = document.getElementById('theme-toggle');


function toggleTheme() {
    const body = document.body;
    body.classList.toggle('dark-mode');

    if (body.classList.contains('dark-mode')) {
        localStorage.setItem('theme', 'dark-mode');
    } else {
        localStorage.setItem('theme', 'light-mode');
    }
}


function restoreTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark-mode') {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
}


themeToggle.addEventListener('click', toggleTheme);

document.addEventListener('DOMContentLoaded', restoreTheme);


const imagesWithLinks = {
    image3: 'index2.html',
    image4: 'index6.html',
    image8: 'index3.html',
    image9: 'index.html'
};

Object.keys(imagesWithLinks).forEach(id => {
    const image = document.getElementById(id);
    if (image) {
        image.addEventListener('click', () => {
            window.location.href = imagesWithLinks[id];
        });
        image.setAttribute('data-href', 'true'); 
    }

const infoPanel = document.getElementById('info-panel');
const closePanelButton = document.getElementById('close-panel');


function openInfoPanel() {
    infoPanel.style.display = 'block'; 
}


function closeInfoPanel() {
    infoPanel.style.display = 'none'; 
}


const image5 = document.getElementById('image5');
const image10 = document.getElementById('image10');

if (image5) {
    image5.addEventListener('click', openInfoPanel);
}

if (image10) {
    image10.addEventListener('click', openInfoPanel);
}


if (closePanelButton) {
    closePanelButton.addEventListener('click', closeInfoPanel);
}
});
