
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');
const homeIcon = document.getElementById('home-icon');


function toggleTheme() {
    const body = document.body;
    body.classList.toggle('dark-mode');

   
    if (body.classList.contains('dark-mode')) {
        themeIcon.src = 'images/sun-icon.png'; 
        localStorage.setItem('theme', 'dark-mode');
    } else {
        themeIcon.src = 'images/moon-icon.png'; 
        localStorage.setItem('theme', 'light-mode');
    }
}


function restoreTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark-mode') {
        document.body.classList.add('dark-mode');
        themeIcon.src = 'images/sun-icon.png'; 
    } else {
        document.body.classList.remove('dark-mode');
        themeIcon.src = 'images/moon-icon.png'; 
    }
}


if (homeIcon) {
    homeIcon.addEventListener('click', function () {
        window.location.href = 'index5.html'; 
    });
}


themeToggle.addEventListener('click', toggleTheme);


document.addEventListener('DOMContentLoaded', restoreTheme);

document.addEventListener('DOMContentLoaded', restoreTheme);
const vase = document.getElementById('vase');
if (vase) { 
    vase.addEventListener('click', function () {
        window.location.href = 'index3.html'; 
    });
}
document.addEventListener('DOMContentLoaded', restoreTheme);
const butterfly = document.getElementById('butterfly');
if (butterfly) { 
    butterfly.addEventListener('click', function () {
        window.location.href = 'index.html'; 
    });
}