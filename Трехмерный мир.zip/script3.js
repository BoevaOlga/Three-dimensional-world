
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');
const homeIcon = document.getElementById('home-icon');
const stena = document.getElementById('stena');
const bashnya = document.getElementById('bashnya');


function toggleTheme() {
    const body = document.body;
    const isDarkMode = body.classList.toggle('dark-mode');

    themeIcon.src = isDarkMode ? 'images/sun-icon.png' : 'images/moon-icon.png';
    localStorage.setItem('theme', isDarkMode ? 'dark-mode' : 'light-mode');
}

function restoreTheme() {
    const savedTheme = localStorage.getItem('theme');
    const isDarkMode = savedTheme === 'dark-mode';

    document.body.classList.toggle('dark-mode', isDarkMode);
    themeIcon.src = isDarkMode ? 'images/sun-icon.png' : 'images/moon-icon.png'; 
}
if (homeIcon) {
    homeIcon.addEventListener('click', () => {
        window.location.href = 'index5.html'; 
    });
}


if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
}


document.addEventListener('DOMContentLoaded', restoreTheme);


if (stena) {
    stena.addEventListener('click', () => {
        window.location.href = 'index2.html'; 
    });
}

if (bashnya) {
    bashnya.addEventListener('click', () => {
        window.location.href = 'index6.html'; 
    });
}